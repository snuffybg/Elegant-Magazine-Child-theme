<?php

	//Elegant Magazine Child Theme

	add_action( 'wp_enqueue_scripts', 'load_child_theme_enqueue_scripts' );

	function load_child_theme_enqueue_scripts(){

		wp_enqueue_style('child-theme-css', get_stylesheet_uri());

	}


	/* CUSTOM PHP CODE GOES HERE */


				